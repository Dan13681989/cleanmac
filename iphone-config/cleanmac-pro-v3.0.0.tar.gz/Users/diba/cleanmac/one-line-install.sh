#!/bin/bash
# One-line CleanMac installer
bash <(curl -sSL https://raw.githubusercontent.com/Dan13681989/cleanmac/main/install.sh)
