#!/bin/bash
echo "Hello from iPhone sync!"
