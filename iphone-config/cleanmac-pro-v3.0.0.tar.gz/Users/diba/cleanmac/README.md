# CleanMac - macOS Scripts
Professional cleanup scripts.
