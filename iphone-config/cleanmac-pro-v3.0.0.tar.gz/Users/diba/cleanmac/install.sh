#!/bin/bash
echo "Installing CleanMac..."
sudo cp cleanmac.sh /usr/local/bin/cleanmac
sudo chmod +x /usr/local/bin/cleanmac
echo "✅ Installed! Run 'cleanmac'"
